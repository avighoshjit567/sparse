<!-- BEGIN: Sidebar-->
            <div class="page-sidebar custom-scroll" id="sidebar">
                <div class="sidebar-header"><a class="sidebar-brand" href="<?php echo e(URL::to('dashboard')); ?>">IT Plan BD</a><a class="sidebar-brand-mini" href="index.html">Rd</a><span class="sidebar-points"><span class="badge badge-success badge-point mr-2"></span><span class="badge badge-danger badge-point mr-2"></span><span class="badge badge-warning badge-point"></span></span></div>
                <ul class="sidebar-menu metismenu">
                    <li class="heading"><span>DASHBOARDS</span></li>
                    <li class="mm-active"><a href="<?php echo e(URL::to('/dashboard')); ?>">
                        <i class="sidebar-item-icon ft-home"></i><span class="nav-label">Dashboards</span></a>
                    </li>
                    <li><a href="javascript:;"><i class="sidebar-item-icon ft-anchor"></i><span class="nav-label">User</span><i class="arrow la la-angle-right"></i></a>
                        <ul class="nav-2-level">
                            <li><a href="<?php echo e(route('view')); ?>">User</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- END: Sidebar-->
<?php /**PATH D:\xampp\htdocs\itplanbd-admin\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>