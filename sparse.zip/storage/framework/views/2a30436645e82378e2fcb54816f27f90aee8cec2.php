<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="container">
        <form id="permission_update_form" action="<?php echo e(route('user_restictions.update')); ?>" method="post"
            class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php if($user): ?>
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Module Name</th>
                            <th>Restictions <input type="checkbox" onclick="checkAll(this)">
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permissionCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr
                                style="background-color:#6C8BEF; color:white;text-align:center;text-transform:capitalize;font-weight:bolder;">
                                <td colspan="3"><?php echo e($key); ?></td>
                            </tr>
                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($permissionCategory->id); ?></td>
                                    <td><?php echo e($permissionCategory->title); ?></td>
                                    <td>
                                        <input type="checkbox" name="permission[]" value="view <?php echo e($permissionCategory->name); ?>" <?php if(in_array("view $permissionCategory->name", $permissions)): ?> checked <?php endif; ?>>
                                        <span>View</span>
                                        <input type="checkbox" name="permission[]" value="edit <?php echo e($permissionCategory->name); ?>" <?php if(in_array("view $permissionCategory->name", $permissions)): ?> checked <?php endif; ?>>
                                        <span>Edit</span>
                                        <input type="checkbox" name="permission[]" value="delete <?php echo e($permissionCategory->name); ?>" <?php if(in_array("view $permissionCategory->name", $permissions)): ?> checked <?php endif; ?>>
                                        <span>Delete</span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <center>
                <button type="submit" class="btn btn-success ">
                    Update
                </button>
            </center>
        </form>
    </div>

</body>

</html>
<?php /**PATH E:\xamp\htdocs\example-app\resources\views/user_restictions.blade.php ENDPATH**/ ?>