<?php $__env->startSection('content'); ?>

<!-- BEGIN: Page heading-->
<div class="page-heading">
    <div class="page-breadcrumb">
        <h1 class="page-title">Dashboard</h1>
    </div>
    <div class="subheader_daterange" id="subheader_daterange"><span class="subheader-daterange-label"><span class="subheader-daterange-title"></span><span class="subheader-daterange-date"></span></span><button class="btn btn-floating btn-sm rounded-0" type="button"><i class="ti-calendar"></i></button></div>
</div>
<!-- BEGIN: Page content-->
<div>

</div><!-- END: Page content-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sparse\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>