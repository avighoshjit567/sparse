<?php $__env->startSection('content'); ?>

<main class="main">
            <div class="category-banner-container bg-gray">
                <div class="category-banner banner text-uppercase" style="background: no-repeat 60%/cover url('<?php echo e(asset('assets/images/banners/banner-top.jpg')); ?>');">
                    <div class="container position-relative">
                        <div class="row">
                            <div class="pl-lg-5 pb-5 pb-md-0 col-md-5 col-xl-4 col-lg-4 offset-1">
                                <h3>SPARSE Gadget<br>Deals</h3>
                                <a href="#" class="btn btn-dark">Get Yours!</a>
                            </div>
                            <div class="pl-lg-3 col-md-4 offset-md-0 offset-1 pt-3">
                                <div class="coupon-sale-content">
                                    <h4 class="m-b-1 coupon-sale-text bg-white text-transform-none">Exclusive OFFER
                                    </h4>
                                    <h5 class="mb-2 coupon-sale-text d-block ls-10 p-0"><i class="ls-0">UP TO</i><b class="text-dark">৳1000</b> OFF</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                
                <br><br>
                <div class="row" style="">
                    <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $Category = App\Models\Category::where('id',$Product->category_id)->first();
                    $category_name = str_replace(" ","-",$Category->name);
                    $ProductImageQueryCount = App\Models\ProductImages::where('product_id',$Product->id)->orderBy('id','asc')->count();
                    $ProductImageQuery = App\Models\ProductImages::where('product_id',$Product->id)->orderBy('id','asc')->take(2)->get();
                    // dd($ProductImageQuery);
                    $new_product_name = str_replace(" ","-",$Product->name);
                    ?>
                        <div class="col-6 col-sm-4 col-md-3 col-xl-5col">
                            <div class="product-default" style="height:420px;">
                                <figure>
                                    <?php if($ProductImageQueryCount > 0): ?>
                                    <a href="<?php echo e(URL::to('product-details')); ?>/<?php echo e($new_product_name); ?>/<?php echo e($Product->id); ?>">
                                        <img src="<?php echo e(asset($ProductImageQuery[0]->image)); ?>" width="280" height="280" alt="product" />
                                        <?php if($ProductImageQueryCount > 1): ?>
                                            <img src="<?php echo e(asset($ProductImageQuery[1]->image)); ?>" width="280" height="280" alt="product" />
                                        <?php endif; ?>
                                    </a>
                                    <?php else: ?>
                                    <a href="<?php echo e(URL::to('product-details')); ?>/<?php echo e($new_product_name); ?>/<?php echo e($Product->id); ?>">
                                        <img src="<?php echo e(asset('images/no-image.jpg')); ?>" width="280" height="280" alt="product" />
                                    </a>
                                    <?php endif; ?>

                                    
                                </figure>

                                <div class="product-details">
                                    <div class="category-wrap">
                                        <div class="category-list">
                                            <a href="<?php echo e(URL::to('categorywise-product')); ?>/<?php echo e($category_name); ?>/<?php echo e($Category->id); ?>" class="product-category"><?php echo e($Category->name); ?></a>
                                        </div>
                                    </div>

                                    <h3 class="product-title"> <a href="<?php echo e(URL::to('product-details')); ?>/<?php echo e($new_product_name); ?>/<?php echo e($Product->id); ?>"><?php echo e($Product->name); ?></a>
                                    </h3>

                                    <div class="ratings-container">
                                        <div class="product-ratings">
                                            <span class="ratings" style="width:100%"></span>
                                            <!-- End .ratings -->
                                            <span class="tooltiptext tooltip-top"></span>
                                        </div>
                                        <!-- End .product-ratings -->
                                    </div>
                                    <!-- End .product-container -->

                                    <div class="price-box">
                                        <?php if($Product->discount_amount): ?>
                                            <span class="old-price">৳<?php echo e($Product->sale_price); ?></span>
                                            <span class="product-price">৳<?php echo e($Product->sale_price - $Product->discount_amount); ?></span>
                                        <?php else: ?>
                                            <span class="product-price">৳<?php echo e($Product->sale_price); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- End .price-box -->

                                    <div class="product-action">
                                        <a href="javascript:void(0);" class="btn-icon btn-add-cart add-to-cart" data-id="<?php echo e($Product->id); ?>"><i class="icon-shopping-cart"></i><span>ADD TO CART</span></a>
                                    </div>
                                </div>
                                <!-- End .product-details -->
                            </div>
                        </div>
                        <!-- End .col-sm-4 -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!-- End .row -->

                
            </div>
            <!-- End .container -->
            <

        </main>
        <!-- End .main -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sparse\resources\views/website/category_wise_product.blade.php ENDPATH**/ ?>