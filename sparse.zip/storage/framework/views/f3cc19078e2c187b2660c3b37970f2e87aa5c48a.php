<?php $__env->startSection('content'); ?>

<main class="main">
    <div class="container">
        <nav aria-label="breadcrumb" class="breadcrumb-nav">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>"><i class="icon-home"></i></a></li>
                <li class="breadcrumb-item"><a href="#">Products</a></li>
            </ol>
        </nav>

        <div class="product-single-container product-single-default">


            <div class="row">
                <div class="col-lg-5 col-md-6 product-single-gallery">
                    <div class="product-slider-container">
                        

                        <div class="product-single-carousel owl-carousel owl-theme show-nav-hover">
                            <?php $__currentLoopData = $ProductImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ProductImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-item">
                                    <img class="product-single-image" src="<?php echo e(asset($ProductImage->image)); ?>" data-zoom-image="<?php echo e(asset($ProductImage->image)); ?>" width="468" height="468" alt="product" />
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <!-- End .product-single-carousel -->
                        <span class="prod-full-screen">
                            <i class="icon-plus"></i>
                        </span>
                    </div>

                    <div class="prod-thumbnail owl-dots">
                        <?php $__currentLoopData = $ProductImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ProductImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="owl-dot">
                                <img src="<?php echo e(asset($ProductImage->image)); ?>" width="110" height="110" alt="product-thumbnail" />
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <!-- End .product-single-gallery -->

                <div class="col-lg-7 col-md-6 product-single-details">
                    <h1 class="product-title"><?php echo e($Products->name); ?></h1>

                    
                    <!-- End .ratings-container -->

                    <hr class="short-divider">

                    <div class="price-box">
                        <?php if($Products->discount_amount): ?>
                            <span class="old-price">৳<?php echo e($Products->sale_price); ?></span>
                            <span class="product-price">৳<?php echo e(number_format($Products->sale_price - $Products->discount_amount,2)); ?></span>
                        <?php else: ?>
                            <span class="product-price">৳<?php echo e($Products->sale_price); ?></span>
                        <?php endif; ?>
                    </div>
                    <!-- End .price-box -->

                    <div class="product-desc">
                        <p>
                            <?php echo e($Products->short_description); ?>

                        </p>
                    </div>
                    <!-- End .product-desc -->

                    <ul class="single-info-list">

                        <li>
                            CATEGORY: <strong><a href="#" class="product-category"><?php echo e($Products->Category ? $Products->Category->name:''); ?></a></strong>
                        </li>

                        <li>
                            BRAND: <strong><a href="#" class="product-category"><?php echo e($Products->Brand ? $Products->Brand->name:''); ?></a></strong>
                        </li>
                    </ul>

                    <div class="product-action">
                        <div class="product-single-qty">
                            <input class="horizontal-quantity form-control" type="text">
                        </div>
                        <!-- End .product-single-qty -->

                        <a href="javascript:;" class="btn btn-dark add-cart add-to-cart mr-2" data-id="<?php echo e($Products->id); ?>" title="Add to Cart">Add to
                            Cart</a>

                        <a href="<?php echo e(route('cart')); ?>" class="btn btn-gray view-cart d-none">View cart</a>
                    </div>
                    <!-- End .product-action -->

                    <hr class="divider mb-0 mt-0">

                    <div class="product-single-share mb-3">
                        <label class="sr-only">Share:</label>

                        <div class="social-icons mr-2">
                            <a href="#" class="social-icon social-facebook icon-facebook" target="_blank" title="Facebook"></a>
                            <a href="#" class="social-icon social-twitter icon-twitter" target="_blank" title="Twitter"></a>
                            <a href="#" class="social-icon social-linkedin fab fa-linkedin-in" target="_blank" title="Linkedin"></a>
                            <a href="#" class="social-icon social-gplus fab fa-instagram" target="_blank" title="Instagram"></a>
                            <a href="#" class="social-icon social-mail icon-mail-alt" target="_blank" title="Mail"></a>
                        </div>
                        <!-- End .social-icons -->

                        
                    </div>
                    <!-- End .product single-share -->
                </div>
                <!-- End .product-single-details -->
            </div>
            <!-- End .row -->
        </div>
        <!-- End .product-single-container -->

        <div class="product-single-tabs">
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="product-tab-desc" data-toggle="tab" href="#product-desc-content" role="tab" aria-controls="product-desc-content" aria-selected="true">Description</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" id="product-tab-tags" data-toggle="tab" href="#product-tags-content" role="tab" aria-controls="product-tags-content" aria-selected="false">Additional
                        Information</a>
                </li>

                
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade show active" id="product-desc-content" role="tabpanel" aria-labelledby="product-tab-desc">
                    <div class="product-desc-content">
                        <p><?php echo $Products->long_description; ?></p>
                    </div>
                    <!-- End .product-desc-content -->
                </div>
                <!-- End .tab-pane -->

                <div class="tab-pane fade" id="product-tags-content" role="tabpanel" aria-labelledby="product-tab-tags">
                    <?php echo $Products->additional_info; ?>

                </div>
                <!-- End .tab-pane -->

                
                <!-- End .tab-pane -->
            </div>
            <!-- End .tab-content -->
        </div>
        <!-- End .product-single-tabs -->

        <div class="products-section pt-0">
            <h2 class="section-title">Related Products</h2>

            <div class="products-slider owl-carousel owl-theme dots-top dots-small">
                <?php $__currentLoopData = $Related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $Category = App\Models\Category::where('id',$Related_product->category_id)->first();
                        $category_name = str_replace(" ","-",$Category->name);
                        $ProductImageQueryCount = App\Models\ProductImages::where('product_id',$Related_product->id)->orderBy('id','asc')->count();
                        $ProductImageQuery = App\Models\ProductImages::where('product_id',$Related_product->id)->orderBy('id','asc')->take(2)->get();
                        // dd($ProductImageQuery);
                        $new_product_name = str_replace(" ","-",$Related_product->name);

                    ?>
                    <div class="product-default">
                        <figure>
                                <?php if($ProductImageQueryCount > 0): ?>
                                <a href="<?php echo e(URL::to('product-details')); ?>/<?php echo e($new_product_name); ?>/<?php echo e($Related_product->id); ?>">
                                    <img src="<?php echo e(asset($ProductImageQuery[0]->image)); ?>" width="280" height="280" alt="product" />
                                    <?php if($ProductImageQueryCount > 1): ?>
                                        <img src="<?php echo e(asset($ProductImageQuery[1]->image)); ?>" width="280" height="280" alt="product" />
                                    <?php endif; ?>
                                </a>
                                <?php else: ?>
                                <a href="<?php echo e(URL::to('product-details')); ?>/<?php echo e($new_product_name); ?>/<?php echo e($Related_product->id); ?>">
                                    <img src="<?php echo e(asset('images/no-image.jpg')); ?>" width="280" height="280" alt="product" />
                                </a>
                                <?php endif; ?>

                                
                        </figure>
                        <div class="product-details">
                            <div class="category-list">
                                <a href="<?php echo e(URL::to('categorywise-product')); ?>/<?php echo e($category_name); ?>/<?php echo e($Category->id); ?>" class="product-category"><?php echo e($Category->name); ?></a>
                            </div>
                            <h3 class="product-title">
                                <a href="<?php echo e(URL::to('product-details')); ?>/<?php echo e($new_product_name); ?>/<?php echo e($Related_product->id); ?>"><?php echo e($Related_product->name); ?></a>
                            </h3>
                            
                            <!-- End .product-container -->
                            <div class="price-box">
                                <?php if($Related_product->discount_amount): ?>
                                    <span class="old-price">৳<?php echo e($Related_product->sale_price); ?></span>
                                    <span class="product-price">৳<?php echo e(number_format($Related_product->sale_price - $Related_product->discount_amount,2)); ?></span>
                                <?php else: ?>
                                    <span class="product-price">৳<?php echo e($Related_product->sale_price); ?></span>
                                <?php endif; ?>
                            </div>
                            <!-- End .price-box -->
                            <div class="product-action">
                                <a href="javascript:void(0);" class="btn-icon btn-add-cart add-to-cart" data-id="<?php echo e($Related_product->id); ?>"><i class="icon-shopping-cart"></i><span>ADD TO CART</span></a>
                            </div>
                        </div>
                        <!-- End .product-details -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- End .products-slider -->
        </div>
        <!-- End .products-section -->
        <!-- End .row -->
    </div>
    <!-- End .container -->
</main>
<!-- End .main -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sparse\resources\views/website/product_details.blade.php ENDPATH**/ ?>